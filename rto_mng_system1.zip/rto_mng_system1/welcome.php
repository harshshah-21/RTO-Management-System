<?php
  
  
?>
<?php
	session_start();
  if(isset($_SESSION['userid'])) 
 {
       header("location: welcome.php");
		die();			 
	 }
	 
	  include('header1.php');
?>


<!DOCTYPE html>
<html>
<head>
<title>Welcome</title>
<!-- For-Mobile-Apps -->
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //For-Mobile-Apps -->
<!-- Style --> <link rel="stylesheet" href="css/style.css" type="text/css" media="all" />

<style>
	.main_category button{
		padding:5%;
		border:1px solid black;
		border-radius:25px;
		font-size:25px;
		background-color;
		
		display:inline-block;


box-sizing: border-box;
text-decoration:none;
font-family:'Roboto',sans-serif;

text-align:center;
transition: all 0.2s;
	}
</style>
</head>
<body>
<div class="container" style="margin-left:12%;color:white;font-size:25px;">

	<div style="font-size:25px;margin-top:17%" class="main_category">
	<a href="license.php"><button style="float:left;margin-left:0%">Licence</button></a>
	<a href="rmv.php"> <button style="margin-left:7%">Regestration of Motor Vehicle</button></a>
	<a href="permit.php"><button style="margin-left:7%;">Permit</button></a>
	</div>
	<br>
	
</div>
<div class="footer">
   <!--  <p>Copyright &copy; 2017 Cosmo Login Form. All Rights Reserved </p>-->
</div>
</body>
</html>