<?php
  
     include('header1.php');
?>


<!DOCTYPE html>
<html>
<head>
<title>Registration of vehiclex</title>
<!-- For-Mobile-Apps -->
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //For-Mobile-Apps -->
<!-- Style --> <link rel="stylesheet" href="css/style.css" type="text/css" media="all" />

<style>
	.sub_category a button{
		padding:5%;
		border:1px solid black;
		border-radius:25px;
		font-size:25px;
		background-color;
		
		display:inline-block;


box-sizing: border-box;
text-decoration:none;
font-family:'Roboto',sans-serif;

text-align:center;
transition: all 0.2s;
	}
</style>
</head>
<body>
<div class="container" style="margin-left:10%;color:white;font-size:25px;width:90%;height:auto;">

	
	
	
	
	<div style="font-size:25px;margin-top:17%" class="sub_category">
	<a href="reg_motor_vehicle.php"><button style="float:left;margin-left:-10%">Registration of Motor Vehicle</button></a>

	<a href="transfer.php"><button style="margin-left:.5%;">Transfer Of Ownership</button></a>
	<a href="duplicate_reg.php"><button style="margin-left:0%;"> Duplicate Registration Certificate</button></a>
	</div>
	<br>
	
</div>
<div class="footer">
    <p>Copyright &copy; 2017 All Rights Reserved </p>
</div>
</body>
</html>