<?php
	
 
	$time = date("Y-m-d H:i:s");
	
	
	
	
	
	
?>