<?php
  
     include('header1.php');
?>


<!DOCTYPE html>
<html>
<head>
<title>Welcome</title>
<!-- For-Mobile-Apps -->
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //For-Mobile-Apps -->
<!-- Style --> <link rel="stylesheet" href="css/style.css" type="text/css" media="all" />

<style>
	.sub_category button{
		padding:5%;
		border:1px solid black;
		border-radius:25px;
		font-size:25px;
		background-color;
		
		display:inline-block;


box-sizing: border-box;
text-decoration:none;
font-family:'Roboto',sans-serif;

text-align:center;
transition: all 0.2s;
	}
</style>
</head>
<body>
<div class="container" style="margin-left:12%;color:white;font-size:25px;">

	
	
	
	
	<div style="font-size:25px;margin-top:17%" class="sub_category">
	<a href="learning.php"><button style="float:left;margin-left:-10%">Learning Licence</button></a>
	<a href="driving.php"> <button style="margin-left:1%">Driving Licence</button></a>
	<a href="renewal_of_dl.php"><button style="margin-left:.5%;">Renewal of DL</button></a>
	<a href="duplicate.php"><button style="margin-left:0.5%;">Apply for duplicate</button></a>
	</div>
	<br>
	
</div>
<div class="footer">
   <!--  <p>Copyright &copy; 2017 Cosmo Login Form. All Rights Reserved </p>-->
</div>
</body>
</html>